@echo off
chcp 65001 >NUL
set "CACHE=%USERPROFILE%\AppData\LocalLow\Yangyang Mobile\The Letter"
if exist "%CACHE%" copy /Y "%~dp0The Letter_Data\StreamingAssets\SqlText\*.sq" "%CACHE%\" >NUL
echo Готово.
